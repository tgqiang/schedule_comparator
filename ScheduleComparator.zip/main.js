/* 
 * // MAIN.JS FOR SCHEDULECOMPARATOR.HTML //
 * CONTAINS THE SCRIPTING FOR THE HOME PAGE.
 */

/* READY FUNCTIONS */
$(document).ready(function() {  
  // ACCORDION EFFECT FOR USEFUL LINKS
	$(".accordion").accordion({
    collapsible: true,
    active: false
  });
})